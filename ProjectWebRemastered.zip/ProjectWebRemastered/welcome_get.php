<html>
<body>
<header>
    <h3>
Welcome <?php echo $_GET["name"]; ?><br>
Your email address is: <?php echo $_GET["email"]; ?>
    </h3>
    </header>

</body>
</html>