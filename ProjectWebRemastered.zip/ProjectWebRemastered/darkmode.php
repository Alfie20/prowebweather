<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
}
.menu {
  float: left;
  width: 20%;
}
.menuitem {
  padding: 15px;
  margin-top: 7px;
  border-bottom: 1px solid #f1f1f1;
}
.main {
 float: left;
  width: 60%;
  padding: 0 20px;
  overflow: hidden;
}
.right {
  background-color:  #1e2d44;
  float: left;
  width: 20%;
  padding: 10px 15px;
  margin-top: 7px;
  box-shadow: 5px 10px 8px 10px #888888;
}

@media only screen and (max-width:800px) {
  /* For tablets: */
  .main {
    width: 80%;
    padding: 0;
  }
  .right {
    width: 100%;
  }
}
@media only screen and (max-width:500px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width: 100%;
  }
}
    td{
    border-bottom: 2px solid black;
    background-color: whitesmoke;
   
}
    td:hover{
        background-color:aqua;
        box-shadow: 5px 5px 10px black;
        border-radius: 5px;
        transition: 0.5s;
        transform: scale(1.2);
        
    }
    
    
    
    .sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color:  #1e2d44;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
 border-top-right-radius: 5px;
       
        
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 18px;
  color: whitesmoke;
  display: block;
  transition: 0.3s;
   
}

.sidenav a:hover {
  color: white;
    
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 65px;
}

#mainav {
  transition: margin-left .5s;
  padding:0;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
    
    .pindotanan:hover{
         transform: scale(1.2);
    }
    .openan:hover{
         transform: scale(1.2);
    }
    .hov a:hover{
        transform: scale(1.2);
        transition: 0.5s;
        border-radius: 10px;
        box-shadow: 1px 1px 10px  #00b3b3;
    }
</style>
</head>
<body id="mainav" style="font-family:Verdana;margin: 0;padding: 0;background-color:  #1e2d44;">
<header style="margin-top: -20px;">

<div  style="background-image: url(star.jpg); background-size: cover;height: 200px; background-position:center; box-shadow: 1px 1px 5px  #00b3b3;">
     <span class="openan" style="font-family: sans-serif;  font-size:24px;cursor:pointer; margin-top: 10px;margin-left: 20px; color: white;position: absolute;" onclick="openNav()">&#9776;</span>
        <h1 style="margin-top: 20px; margin-left:100px;color: #00b3b3;padding: 10px 15px; font-family: sans-serif;">Agro Weather Eye</h1>
      
    <center>
       <input style="height: 35px;width: 200px; border-radius: 5px; border: none;  box-shadow: 5px 5px 20px  #00b3b3;"   type="text" name="user" class="form-control" id="cityname" placeholder="Location Name:Eg:Bulacao">
       <label  for="number-of-days"></label>
        <input style="height: 35px;width: 200px; border-radius: 5px; border: none;  box-shadow: 5px 5px 20px  #00b3b3;" type="text" class="form-control" id="days" placeholder="Number of days:min:1 max:16">
        <button class="pindotanan"  style="height: 35px;width: 80px;box-shadow: 1px 5px 10px  #00b3b3;background-color: #ffb84d;border: none; border-radius: 5px; margin-top: 7px;"  id="submitCity" class="btn btn-primary" onclick="getForecast(document.getElementById('cityname').value,document.getElementById('days').value);">&#128269;</button>
       </center> 
</div>
</header>
<div style="overflow:auto">
  <div class="menu">
   
  <a style="margin-top: 7px;margin-left: 7px;box-shadow: 1px 1px 5px  #00b3b3;" class="weatherwidget-io" href="https://forecast7.com/en/10d32123d89/cebu-city/" data-label_1="CEBU" data-label_2="WEATHER" data-mode="Current" data-theme="weather_one" >CEBU WEATHER</a>
<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
</script>
      <div style="text-align: center;font-family: sans-serif; box-shadow: 1px 1px 10px aqua;width: 100%;margin-left: 7px;border-radius: 5px;">
          <h4 style="margin-bottom: 5px;color: white;">Philippine Satellite</h4>
        <iframe width="100%" height="450" src="https://embed.windy.com/embed2.html?lat=10.963&lon=123.135&zoom=5&level=surface&overlay=wind&menu=&message=true&marker=true&calendar=&pressure=&type=map&location=coordinates&detail=&detailLat=10.310&detailLon=123.893&metricWind=default&metricTemp=default&radarRange=-1" frameborder="0"></iframe>
          </div>
  </div>

  <div class="main">
    
      <div style="margin-top: 7px;overflow-x:auto;font-family: sans-serif;margin-left: 10px; "  class="table-responsive">
 <table style="border: 1px solid aqua;border-radius: 5px;background-color:  #1e2d44;"  class="table table-bordered  table-condensed">
          <thead>
                <center> <h4 style="color:white;" id="location"></h4></center>
            <tr>
              <th style=" width: 10%; border: 1px solid #ddd;background-color: #1e2d44;color: white;" class="ico" >Icon</th>
              <th style="width: 10%; border: 1px solid #ddd;background-color: #1e2d44;color: white;">Weather</th>
              <th style="width: 10%; border: 1px solid #ddd;background-color:  #1e2d44;color: white;">Description</th>
              <th style="width: 10%; border: 1px solid #ddd;background-color:  #1e2d44;color: white;">Morning</th>
              <th style="width: 10%; border: 1px solid #ddd;background-color:  #1e2d44;color: white;">Night</th>
              <th style="width: 10%; border: 1px solid #ddd;background-color:  #1e2d44;color: white;">Min</th>
              <th style="width: 10%; border: 1px solid #ddd;background-color: #1e2d44;color: white;">Max</th>
              <th style="width: 10%; border: 1px solid #ddd;background-color: #1e2d44;color: white;">Pressure</th>
              <th style=" border: 1px solid #ddd;background-color:#1e2d44;color: white;">Humidity</th>
              <th style=" border: 1px solid #ddd;background-color: #1e2d44;color: white;">Wind Speed</th>
            </tr>
          </thead> 
          <tbody style="border: 1px solid #ddd;" id="forecast">
            
          </tbody> 
        </table>
  </div>
    </div>

  <div class="right">
         <canvas style="margin-left: 10px;" id="canvas" width="100" height="100"style="background-color:#333"></canvas>
         <p style="font-family: sans-serif;color: aqua; border: 1px solid white; font-size: 14px; width: 120px; height: 100px; margin-top: -100px;margin-left: 130px;" id="demo"></p>
      
        <script type="text/javascript" src="http://moonphases.co.uk/js/widget.js" id="moonphase_widget" widget="" lat="" lng="" date="" tz=""></script>
      <div style="margin-left: 45px;">
    <script  src="https://www.tidetimes.org.uk/grimsby-tide-times.js" type="text/javascript"></script></div>

  </div>
</div>
      <div style="font-family: sans-serif;" id="mySidenav" class="sidenav">
    <!--close nav-->
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> 
    <div>
        
    <a style="margin-top: -50px;border-bottom: 2px solid white;" href="#"><h5 style="font-size: 20px; margin-bottom: 10px;">Agro Weather Eye</h5></a></div> 
           <div style="border-bottom:2px solid black;" >   
<a  href="register.php" ><button >Sign up</button></a>
<a style="margin-top:-38px;margin-left: 100px;"  href="login.php" ><button >Sign in</button></a>
          </div>     
          <div class="hov">
              
    <a style="border-bottom: 1px solid white;" class="dark" href="guide.php"><span class="line"></span>Daymode</a>
    <a style="border-bottom: 1px solid white;" class="dark" href="moonphase.html"> MoonPhase</a>
    <a style="border-bottom: 1px solid white;" class="dark" href="https://www.techpopop.com/2012/07/philippine-climate-and-planting.html">Cropclopedia</a>
    <a style="border-bottom: 1px solid white;"  href="mapanight.html">Satellite</a>
    <a style="border-bottom: 1px solid white;" href="">News</a>
    <a style="border-bottom: 1px solid white;" href="darkmode.html">Darkmode</a>
  </div>
        </div>

<div style="background-color:black;text-align:center;padding:10px;margin-top:7px;font-size:12px;"></div>
            
<script
  src="https://code.jquery.com/jquery-3.2.1.min.js"
  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"></script>

<!--bootstarp javascript-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<script type="text/javascript" src="script.js"></script>
            <script>
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var radius = canvas.height / 2;
ctx.translate(radius, radius);
radius = radius * 0.90
setInterval(drawClock, 1000);

function drawClock() {
  drawFace(ctx, radius);
  drawNumbers(ctx, radius);
  drawTime(ctx, radius);
}

function drawFace(ctx, radius) {
  var grad;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, 2*Math.PI);
  ctx.fillStyle = 'white';
  ctx.fill();
  grad = ctx.createRadialGradient(0,0,radius*0.95, 0,0,radius*1.05);
  grad.addColorStop(0, '#333');
  grad.addColorStop(0.5, 'white');
  grad.addColorStop(1, '#333');
  ctx.strokeStyle = grad;
  ctx.lineWidth = radius*0.1;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, radius*0.1, 0, 2*Math.PI);
  ctx.fillStyle = '#333';
  ctx.fill();
}

function drawNumbers(ctx, radius) {
  var ang;
  var num;
  ctx.font = radius*0.15 + "px arial";
  ctx.textBaseline="middle";
  ctx.textAlign="center";
  for(num = 1; num < 13; num++){
    ang = num * Math.PI / 6;
    ctx.rotate(ang);
    ctx.translate(0, -radius*0.85);
    ctx.rotate(-ang);
    ctx.fillText(num.toString(), 0, 0);
    ctx.rotate(ang);
    ctx.translate(0, radius*0.85);
    ctx.rotate(-ang);
  }
}

function drawTime(ctx, radius){
    var now = new Date();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    //hour
    hour=hour%12;
    hour=(hour*Math.PI/6)+
    (minute*Math.PI/(6*60))+
    (second*Math.PI/(360*60));
    drawHand(ctx, hour, radius*0.5, radius*0.07);
    //minute
    minute=(minute*Math.PI/30)+(second*Math.PI/(30*60));
    drawHand(ctx, minute, radius*0.8, radius*0.07);
    // second
    second=(second*Math.PI/30);
    drawHand(ctx, second, radius*0.9, radius*0.02);
}

function drawHand(ctx, pos, length, width) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.lineCap = "round";
    ctx.moveTo(0,0);
    ctx.rotate(pos);
    ctx.lineTo(0, -length);
    ctx.stroke();
    ctx.rotate(-pos);
}
</script>
           <script>
var d = new Date();
document.getElementById("demo").innerHTML = d;
</script>
 <!------ Sidenav --->       
        <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("mainav").style.marginLeft = "250px";
  document.body.style.backgroundColor = "#1e2d44";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("mainav").style.marginLeft= "0";
  document.body.style.backgroundColor = "#1e2d44";
}
</script>
    <script> 
        $(document).ready(function() { 
  
            $("button").click(function() { 
                
              //here the value is stored in variable.  
                var x = $("input:text").val();  
  
                document.getElementById("location").innerHTML = x; 
            }); 
  
        }); 
    </script> 
</body>
</html>