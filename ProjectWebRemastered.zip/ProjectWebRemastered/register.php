<?php include('server.php') ?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    body{
        font-family: sans-serif;
        overflow-y: auto;
    }
* {
  box-sizing: border-box;
    
}
   

input[type=text],[type=email],[type=password], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize:vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  margin-top: 7px;
  padding: 20px;
width: 50%;
    margin-right: 10px;
    float: right;
 overflow-y: auto;
  position: fixed;
  right: 0;
  background: rgba(0, 0, 0, 0.5);
  color: #f1f1f1;
 

}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.input-group:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
#myVideo {
  position: fixed;
  right: 0;
  bottom: 0;
  min-width: 100%; 
  min-height: 100%;
}
    button{
        margin-top: 20px;
        background-color:  #33cc33;
        border: none;
        border-radius: 5px;
        width: 100px;
        height: 50px;
        color: white;
    }
    
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}  

</style>
</head>
<body>
    
  
 

    <video autoplay muted loop id="myVideo">
  <source src="clearDay.mp4" type="video/mp4">
  Your browser does not support HTML5 video.
</video>

<div class="container">
    <div class="headed">
    <h2 style="margin-bottom:-10px;">AgroWeatherEye</h2>
    <div style="margin-bottom:-10px;text-align:center;">
        <h4 >Register  Here</h4>
    </div>
    </div>
  <form  method="post" action="register.php"  onsubmit="return validateForm()">
		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" value="<?php echo $username; ?>" required>
		</div>
		<div class="input-group">
			<label>Email</label>
			<input type="email" name="email" value="<?php echo $email; ?>"required>
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password_1"required>
		</div>
		<div class="input-group">
			<label>Confirm password</label>
			<input type="password" name="password_2"required>
		</div>
		<div class="input-group">
             <div class="row">
     <button type="submit" class="btn" name="reg_user">Register</button>
    </div>
		</div>
		<p>
			Already a member? <a style="color:aqua;text-decoration:none;" href="login.php">Sign in</a>
		</p>
      </form>
</div>

</body>
</html>
