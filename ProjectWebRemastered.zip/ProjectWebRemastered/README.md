# weather.github.io
A weather app using javascript,html,css,bootstrap and openweathermap api
A simple and easy to use javascript based web app that uses ajax calls to receive json data from openweathermap api
You can search for the current weather data like temperature,humidity,etc of any city
Yoc can also search for a weather forecast of any city for 1-16 days.
